#include <avr/io.h>
#include <avr/interrupt.h>
#define LED0 PC4
#define LED1 PC5
#define SW0 PD2
#define SW1 PD3
#define LED(x) (1<<x) // Define LED macro
int main(void)
{
	DDRC |= (1<<LED0)|(1<<LED1); // Set output pins
	PORTC |= LED(LED0); // Turn on LED0
	PORTC &= ~LED(LED1); // Turn off LED1
	DDRD &= ~(1<<SW0); // Set PD2 as input
	PORTD |= (1<<SW0); // Enable PD2's pull-up resistor
	DDRD &= ~(1<<SW1); // Set PD3 as input
	PORTD |= (1<<SW1); // Enable PD3's pull-up resistor
	EICRA |= (1<<ISC01)|(0<<ISC00); // Rising edge interrupt for INT0
	EICRA |= (1<<ISC11)|(1<<ISC10); // Falling edge interrupt for INT1
	EIMSK |= (1<<INT0)|(1<<INT1); // Enable INT0 & INT1
	sei(); // Enable global interrupts
	while (1) {}
}
ISR(INT0_vect) //- INT0's ISR
{
	PORTC |= LED(LED0); // Turn on LED0
	PORTC &= ~LED(LED1); // Turn off LED1
}
ISR(INT1_vect) //- INT1's ISR
{
	PORTC &= ~LED(LED0); // Turn off LED0
	PORTC |= LED(LED1); // Turn on LED1
}