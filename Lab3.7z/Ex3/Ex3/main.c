#include <avr/io.h>
#include <avr/interrupt.h>
#define LED PB5
volatile unsigned char prev_PINB=0xFF;
int main(void) {
	DDRB |= _BV(LED);
	PORTB &= ~_BV(LED);
	// Set pin directions & enable pull-up resistors
	DDRB &= ~(_BV(PCINT0)|_BV(PCINT1)|_BV(PCINT2));
	PORTB |= _BV(PCINT0)|_BV(PCINT1)|_BV(PCINT2);
	// Enable pin change intr 0
	PCICR |= _BV(PCIE0)|_BV(PCIE1)|_BV(PCIE2);
	// Enable pin change intr for PB0, PB1, & PB2
	PCMSK0 |= _BV(PCINT0)|_BV(PCINT1)|_BV(PCINT2);
	sei(); // Enable global interrupts
	while (1) {} // Loop
}
//- PCINT0's ISR
ISR(PCINT0_vect) {
	unsigned char rd_bits;
	rd_bits = PINB ^ prev_PINB; // To check if PINB�s updated
	prev_PINB = PINB; // Record PINB
	if ((rd_bits & _BV(PB0))==_BV(PB0)) PORTB ^= _BV(LED); // Toggle LED
	if ((rd_bits & _BV(PB1))==_BV(PB1)) PORTB |= _BV(LED); // Turn on LED
	if ((rd_bits & _BV(PB2))==_BV(PB2)) PORTB &= ~_BV(LED); // Turn off LED
}
