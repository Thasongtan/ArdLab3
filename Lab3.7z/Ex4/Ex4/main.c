#include <avr/io.h>
#include <avr/interrupt.h>
#define LED PB5
#define MAX_CNT 2000
volatile unsigned int cnt = 0;
void fInitTimer() {
	TCCR0A |= (1 << WGM01); // Set Timer0 to CTC mode
	// Set the upper bound for Timer0's counter
	OCR0A = 0xF9;
	// Set Output Compare A Match Interrupt Enable bit
	TIMSK0 |= (1 << OCIE0A);
	// Set prescaler to 64
	TCCR0B |= (1 << CS01) | (1 << CS00);
	sei(); // Enable global interrupts
}
int main(void) {
	DDRB |= _BV(LED); // Set pin directions
	PORTB &= ~_BV(LED); // Turn off LED
	fInitTimer(); // Set Timer0
	while (1) {}
}
// Timer0'Output Compare ISR
ISR (TIMER0_COMPA_vect) {
	cnt++;
	if (cnt==MAX_CNT) {
		PORTB ^= _BV(LED);
		cnt=0;
	}
}